import setuptools

setuptools.setup(
name="models",
version="0.0.1",
author="Sample Project Author",
author_email="author@sample.com",
description="A sample python project",
packages=setuptools.find_packages(include=['dark_vs_bright_model']),
classifiers=[
"Programming Language :: Python :: 3",
"License :: OSI Approved :: MIT License",
"Operating System :: OS Independent"
],
)